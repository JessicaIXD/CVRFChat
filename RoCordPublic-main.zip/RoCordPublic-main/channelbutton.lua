-- credit to https://github.com/VioPaige

script.Parent.MouseButton1Click:Connect(function()
	game.Players.LocalPlayer.PlayerGui.Rocord.ActiveChannel.Value = script.Parent.Id.Value
end)
